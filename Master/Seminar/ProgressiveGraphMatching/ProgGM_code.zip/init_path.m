addpath('./commonFunctions/');
addpath('./BruteSearch120909/');
addpath('./kdtree/');

addpath('./Algorithms/SM/');
addpath('./Algorithms/RRWM/');